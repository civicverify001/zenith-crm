import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { AppLayout } from './Layout'
import { LoginPage } from '../modules/auth/LoginPage'
import { LoadingScreen } from '../shared/ui/LoadingScreen'

// ─── Lazy-loaded module pages (add as we build each phase) ───────
import { DashboardPage } from '../modules/dashboard/DashboardPage'
import { LeadPipelinePage } from '../modules/leads/LeadPipelinePage'

// Placeholder for modules not yet built
const ComingSoon = ({ name }: { name: string }) => (
  <div className="flex items-center justify-center h-full">
    <div className="text-center">
      <div className="text-4xl mb-4">🚧</div>
      <div className="text-xl font-semibold text-slate-300">{name}</div>
      <div className="text-sm text-muted mt-2">Coming in next phase</div>
    </div>
  </div>
)

export function AppRouter() {
  const { session, role, loading } = useAuth()

  if (loading) return <LoadingScreen />
  if (!session) return <LoginPage />

  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardPage />} />

        {/* Phase 4+ modules */}
        <Route path="/leads" element={<LeadPipelinePage />} />
        <Route path="/dispatch" element={<ComingSoon name="Dispatch Board" />} />
        <Route path="/jobs" element={<ComingSoon name="Installation Jobs" />} />
        <Route path="/customers" element={<ComingSoon name="Customers" />} />
        <Route path="/follow-ups" element={<ComingSoon name="Follow-Up Center" />} />
        <Route path="/invoices" element={<ComingSoon name="Accounting" />} />
        <Route path="/inventory" element={<ComingSoon name="Inventory" />} />
        <Route path="/services" element={<ComingSoon name="Plans & Rentals" />} />
        <Route path="/marketing" element={<ComingSoon name="Marketing ROI" />} />
        <Route path="/reports" element={<ComingSoon name="Reports" />} />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </AppLayout>
  )
}
