import type { LeadStage, LeadSource, WaterConcern } from '../../types/domain.types'

// ─── Database row shape ───────────────────────────────────────
export interface Lead {
  id: string
  full_name: string
  phone: string
  email: string | null
  zip_code: string | null
  source: LeadSource
  water_concern: WaterConcern | null
  stage: LeadStage
  assigned_rep_id: string | null
  urgent: boolean
  lost_reason: string | null
  re_engage_date: string | null
  notes: string | null
  stage_changed_at: string
  created_by: string | null
  created_at: string
  updated_at: string
  // Joined
  assigned_rep?: { id: string; full_name: string; role: string } | null
  _call_count?: number
  _days_in_stage?: number
}

// ─── Create / Update payloads ─────────────────────────────────
export interface CreateLeadPayload {
  full_name: string
  phone: string
  email?: string
  zip_code?: string
  address?: string
  source: LeadSource
  water_concern?: WaterConcern
  urgent?: boolean
  notes?: string
  assigned_rep_id?: string
}

export interface UpdateLeadPayload {
  full_name?: string
  phone?: string
  email?: string
  zip_code?: string
  source?: LeadSource
  water_concern?: WaterConcern
  stage?: LeadStage
  assigned_rep_id?: string | null
  urgent?: boolean
  lost_reason?: string
  re_engage_date?: string
  notes?: string
}

// ─── Stage transition rules ───────────────────────────────────
// Maps current stage → allowed next stages (Phase 2)
export const ALLOWED_TRANSITIONS: Partial<Record<LeadStage, LeadStage[]>> = {
  new_lead:             ['qualifying', 'lost', 'dnd'],
  qualifying:           ['qualified', 'future_follow_up', 'lost', 'dnd'],
  qualified:            ['site_visit_scheduled', 'future_follow_up', 'lost'],
  site_visit_scheduled: ['proposal_in_progress', 'qualified', 'lost', 'future_follow_up'],
  proposal_in_progress: ['quote_sent', 'site_visit_scheduled', 'lost'],
  quote_sent:           ['agreement_signed', 'proposal_in_progress', 'lost', 'future_follow_up'],
  agreement_signed:     [], // system only → won (via install complete)
  future_follow_up:     ['qualifying', 'lost', 'dnd'],
  won:                  [],
  lost:                 ['future_follow_up'],
  dnd:                  [],
}

// ─── Stage gate requirements ──────────────────────────────────
export const STAGE_GATE_REQUIREMENTS: Partial<Record<LeadStage, string[]>> = {
  qualifying:           ['name', 'phone', 'source'],
  qualified:            ['water_concern', 'min_1_call_attempt'],
  site_visit_scheduled: ['assigned_rep_id', 'appointment_exists'],
  proposal_in_progress: ['water_test_exists'],
  quote_sent:           ['quote_exists_with_items'],
  agreement_signed:     ['signature', 'deposit', 'install_address'],
}

// ─── Filter / Sort ────────────────────────────────────────────
export interface LeadFilters {
  stage?: LeadStage | 'all'
  assigned_rep_id?: string | 'all'
  source?: LeadSource | 'all'
  urgent?: boolean
  search?: string
}

export type LeadSortField = 'created_at' | 'updated_at' | 'full_name' | 'stage_changed_at'
export type SortDirection = 'asc' | 'desc'
